#ifndef CONFIG_LOADED
#define CONFIG_LOADED

//#define ARMA_NO_DEBUG <- makes slower not faster? :(

#endif 
